title: 【MySQL学习笔记】8.过滤数据
date: '2019-03-31 02:03:16'
updated: '2019-04-04 12:15:23'
tags: [mysql, thetbw, 学习笔记]
permalink: /articles/2019/03/31/1553997796005.html
---
### 过滤数据 使用`where`子句


例：只查询某个值等于多少的数据
```sql
select 列名1,列名2 from 表名 where 列名='值';
```
>如果要使用order by，请把order by放在where子句后边
> **mysql匹配时默认不区分大小写**


|where子句支持的条件操作符 ||
| 操作符| 说明 | 
| --- | --- | 
|  =|  等于|  
| <> |  不等于|  
|!= | 不等于|
|< |  小于|
| <=| 小于等于|
| >| 大于|
|>= | 大于等于|
| between| 在指定的两个值之间|

* 其他

例：`between`
```sql
select 列名1,列名2 from 表名 where 列名 between 起始值 and 结束值;
```
例：空值`null`检查
```sql
select 列名1,列名2 from 表名 where 列名 is null;
```

### 过滤数据 组合`where`子句

#### `and``or`和`not`

与其他编程语言一样`and``or`和`not`分别表示和，与，和否定

例：
```sql
select 列名1,列名2 from 表名 where 列名1=值1 and 列名2=值2;
```
>返回同时满足这两个条件的数据


```
select 列名1,列名2 from 表名 where 列名1=值1 or 列名2=值2;
```
>返回满足其中任意一条件的数据


> **计算次序**： 当多个逻辑操作符组合的时候优先处理and
可以用`()`来明确优先级

#### `in`

例：
```sql
select 列名1,列名2 from 表名 where 列名1 in(值1,值2);
```
>`in(,)`用英文逗号分割，查询满足`()`内任意一值的结果。**不等于between**
in也可用or代替
```
select 列名1,列名2 from 表名 where 列名1=值1 or 列名2=值2;
```
两结果相等

>* 当值比较多使用in时更直观
* 计算的次序更容易管理（因为操作符更少）
* 一般比or执行的更快
* 可以包含其他where子句