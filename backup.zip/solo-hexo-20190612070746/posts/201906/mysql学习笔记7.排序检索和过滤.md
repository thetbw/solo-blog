title: 【mysql学习笔记】7.排序检索和过滤
date: '2019-06-08 12:39:33'
updated: '2019-06-08 12:40:17'
tags: [mysql, java, 学习]
permalink: /articles/2019/06/08/1559997573436.html
---
### 排序检索数据
* `order by`

  使用`order by` 对检索的数据排序
  ```SQL
  select * from 表名 order by 列名;
  ```

  根据多个列名排序

  ```SQL
  select * from 表名 order by 列名1,列名2;
  ```
  >先根据在前的列名排序；

  降序排序`desc`
  ```SQL
  select * from 表名 order by 列名1 desc;
  ```
  >`desc`只作用与前面的名字

### 过滤数据 使用`where`子句



例：只查询某个值等于多少的数据
```sql
select 列名1,列名2 from 表名 where 列名='值';
```
>如果要使用order by，请把order by放在where子句后边
> **mysql匹配时默认不区分大小写**


|where子句支持的条件操作符 ||
| 操作符| 说明 |
| --- | --- |
|  =|  等于|  
| <> |  不等于|  
|!= | 不等于|
|< |  小于|
| <=| 小于等于|
| >| 大于|
|>= | 大于等于|
| between| 在指定的两个值之间|

* 其他

例：`between`
```sql
select 列名1,列名2 from 表名 where 列名 between 起始值 and 结束值;
```
例：空值`null`检查
```sql
select 列名1,列名2 from 表名 where 列名 is null;
```

### 过滤数据 组合`where`子句

#### `and``or`和`not`

与其他编程语言一样`and``or`和`not`分别表示和，与，和否定

例：
```sql
select 列名1,列名2 from 表名 where 列名1=值1 and 列名2=值2;
```
>返回同时满足这两个条件的数据


```
select 列名1,列名2 from 表名 where 列名1=值1 or 列名2=值2;
```
>返回满足其中任意一条件的数据


> **计算次序**： 当多个逻辑操作符组合的时候优先处理and
可以用`()`来明确优先级

#### `in`

例：
```sql
select 列名1,列名2 from 表名 where 列名1 in(值1,值2);
```
>`in(,)`用英文逗号分割，查询满足`()`内任意一值的结果。**不等于between**
in也可用or代替
```
select 列名1,列名2 from 表名 where 列名1=值1 or 列名2=值2;
```
两结果相等

>* 当值比较多使用in时更直观
* 计算的次序更容易管理（因为操作符更少）
* 一般比or执行的更快
* 可以包含其他where子句

  多列降序排序
  ```SQL
  select * from 表名 order by 列名1 desc,列名2 desc;
  ```
 *`asc`升序排序(默认)


 * order by + limit

 ```SQL
 select * from 表名 order by 列名1 desc limit 2;
 ```
 >limit 要在order by之后；
