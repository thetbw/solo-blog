title: 【mysql学习笔记】7.查询数据
date: '2019-03-31 01:38:35'
updated: '2019-04-08 11:45:11'
tags: [mysql, thetbw, 学习笔记]
permalink: /articles/2019/03/31/1553996315293.html
---
### 查询数据

* 检索单个列

  ```sql
  select 列名 from 表名;
  ```

* 检索多个列

  ```sql
  select 列名1,列名2 from 表名;
  ```

* 检索所有列

  ```SQL
  select * from 表名;
  ```

* 检索不同的行
  *使用`distinct`关键字*
  `distinct`只返回数据不同的行
  ```sql
  select distinct 列名 from 表名;

  ```
  >不能使用部分`distinct`除非指定的两个列都不同，否则所有行都将被检索出来。



  #### 限制结果

 使用`limit`限制结果行数

  ```sql
  select * from 表名 limit 5;
  ```
  >表示返回的行数不超过5

* 从第`x`行开始显示不超过`n`行

```sql
select * from 表名 limit x,n;
```
>第一行为0；


#### 使用完全限定的表名

```sql
select 表名.列名 from 数据库名.表名;
```
mysql

## 排序检索数据

* `order by`

  使用`order by` 对检索的数据排序
  ```SQL
  select * from 表名 order by 列名;
  ```

  根据多个列名排序

  ```SQL
  select * from 表名 order by 列名1,列名2;
  ```
  >先根据在前的列名排序；

  降序排序`desc`
  ```SQL
  select * from 表名 order by 列名1 desc;
  ```
  >`desc`只作用与前面的名字

  多列降序排序
  ```SQL
  select * from 表名 order by 列名1 desc,列名2 desc;
  ```
 *`asc`升序排序(默认)


 * order by + limit

 ```SQL
 select * from 表名 order by 列名1 desc limit 2;
 ```
 >limit 要在order by之后；
