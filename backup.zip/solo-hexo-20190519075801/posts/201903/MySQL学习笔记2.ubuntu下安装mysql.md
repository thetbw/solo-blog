title: 【MySQL学习笔记】2. ubuntu下安装mysql
date: '2019-03-31 01:34:23'
updated: '2019-03-31 01:36:08'
tags: [mysql, thetbw, 学习笔记]
permalink: /articles/2019/03/31/1553996063265.html
---
更新源
```
sudo apt-get updata
```
安装mysql
```
sudo apt-get install mysql-server -y
```
使用`mysql_secure_installation`初始化
```
sudo mysql_secure_installation
```
系统会要求您设置密码，然后再提出其他一些问题。

接着安装成功