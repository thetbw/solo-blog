title: 【MyBatis】关于MyBatis提示‘Mapped Statements collection already contains value for’的解决办法
date: '2019-04-13 14:27:19'
updated: '2019-04-13 14:54:02'
tags: [SpringBoot, java, MyBatis, 碰壁]
permalink: /articles/2019/04/13/1555165639350.html
---

最近刚开始学习springboot,按照[how2j](https://)的教程使用MyBatis的时候出现了以下异常
```
java.lang.IllegalArgumentException: Mapped Statements collection already contains value for xyz.thetbw.cloud.dao.LinkDao.findAll. please check xyz/thetbw/cloud/dao/LinkDao.java (best guess) and xyz/thetbw/cloud/dao/LinkDao.java (best guess)
```
![SharedScreenshot.jpg](http://cloud.thetbw.xyz/JRVBTYLDYOA)

大概就是`映射的语句集合已包含值`，
然后几番百度，大概说的就是` mapper.xml `存在多个相同的id,然而我是用springboot加注解创建的，哪来的相同id。
找了半天，终于在google上找到了正确答案（ps:百度还是不靠谱）
[原文地址](https://stackoverflow.com/questions/37085803/mybatis-mapped-statements-collection-already-contains-value-for)

大概就是，mybatis不允许有方法有相同的方法名，即使方法签名不同也不行
只能改名字，比如把`getUser()``getUser(int id)`后者改为`getUserById(int id)`。

＞﹏＜睡觉